// /lib/ai/plans.js
// Limiti token mensili e helper piano utente

export const PLAN_LIMITS = {
    base: 50_000,       // ~12.5k parole
    plus: 300_000,
    pro: 1_000_000,
};

/** Normalizza un nome piano — se non riconosciuto, 'base' */
export function normalizePlan(plan) {
    if (plan === "plus" || plan === "pro") return plan;
    return "base";
}

/** Ritorna il limite token mensile per il piano dato */
export function planLimit(plan) {
    return PLAN_LIMITS[normalizePlan(plan)] || PLAN_LIMITS.base;
}

/** Nome visuale del piano */
export function planName(plan) {
    const names = { base: "Base", plus: "Plus", pro: "Pro" };
    return names[normalizePlan(plan)] || "Base";
}

/** Tabella descrittiva piani — nutrizione + workout nello stesso ecosistema */
export const PLAN_INFO = {
    base: {
        name: "Base",
        price: "Gratis",
        tokens: "50 000/mese",
        features: [
            "Accesso essenziale alla chat AI",
            "Risposte fino a 512 token",
            "Suggerimenti su ricette e 2–3 workout/sett.",
            "Piano settimanale base (non persistente)",
            "Senza memoria: consigli più generici",
            "Limite mensile di 50 000 token",
        ],
    },

    plus: {
        name: "Plus",
        price: "€9,90/mese",
        tokens: "300 000/mese",
        features: [
            "AI adattiva: memorizza gusti, orari e obiettivi",
            "Risposte fino a 1 024 token",
            "Piano settimanale unificato: ricette + allenamenti",
            "Memoria persistente e feedback che influenzano i suggerimenti",
            "Lista spesa smart e cronologia chat",
            "Limite mensile di 300 000 token",
        ],
    },

    pro: {
        name: "Pro",
        price: "€19,90/mese",
        tokens: "1 000 000/mese",
        features: [
            "AI che impara da te nel tempo (evolve con i feedback)",
            "Risposte fino a 2 048 token e priorità alta",
            "Planner adattivo: ricalibra automaticamente pasti e workout",
            "Automazioni settimanali e notifiche smart",
            "Esportazione PDF/CSV e preferenze ingredienti globali",
            "Limite mensile di 1 000 000 token",
        ],
    },
};
