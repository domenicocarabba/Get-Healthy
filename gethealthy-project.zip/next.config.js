/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // ❌ niente: output: 'export'
};
module.exports = nextConfig;
