# Get Healthy — Starter (Next.js 14 + Tailwind)

Landing pulita, SEO base, footer con **All rights reserved**, navbar mobile.

## Setup
```bash
npm install
npm run dev   # http://localhost:3000
```

## Build
```bash
npm run build
npm start
```

## Deploy su Vercel
1) Push su GitHub
2) Importa il repo su Vercel → Deploy
3) DNS: A @ → 76.76.21.21, CNAME www → cname.vercel-dns.com
